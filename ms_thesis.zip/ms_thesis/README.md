# Extracting most predictive subgraphs from models of human brain connectivity
Classification based on graphs
